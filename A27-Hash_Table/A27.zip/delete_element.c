#include "hash.h"

int delete_element(hash_t *arr, int data, int size)
{
    // declaring variable to find the index
    int i = data % size, flag = 0;

    // declaring temp to traverse through the hash table
    hash_t *temp = arr[i].link;
    hash_t *prev = temp;

    if (arr[i].value == data)
    {
        arr[i].value = -1;
        if (temp != NULL)
        {
            arr[i].value = temp->value;
            free(temp);
            arr[i].link = NULL;
        }

        return SUCCESS;
    }

    while (temp != NULL)
    {

        if (temp->value == data)
        {
            temp->value = -1;
            if (temp->link != NULL)
            {
                prev->link = temp->link;
                free(temp);
            }
            else
            {
                prev->link = NULL;
                free(temp);
            }

            return SUCCESS;
        }

        if (flag)
        {
            prev = prev->link;
        }

        temp = temp->link;
        flag = 1;
    }

    return DATA_NOT_FOUND;
}