#include"hash.h"

int search_HT(hash_t *arr, int data, int size)
{
    // declaring variable to find the index
    int i = data % size;

    if (arr[i].value == data)
    {
        return SUCCESS;
    }
    
    // declaring temp to traverse through the hash table
    hash_t *temp = arr[i].link;
    while (temp != NULL)
    {
        if (temp->value == data)
        {
            return SUCCESS;
        }
        
        temp = temp->link;
    }
    
    return DATA_NOT_FOUND;
}